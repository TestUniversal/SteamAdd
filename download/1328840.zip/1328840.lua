-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1328840)
addappid(1328841,0,"ced632dc70dc2b26d0dd6394025b43c0b54e4e580ee72da795b4ce31ced31b7b")
addappid(1328842,0,"08f81f199e072973d6313488cd4722619777b0d46545dfe1fa546f824abb32cf")
